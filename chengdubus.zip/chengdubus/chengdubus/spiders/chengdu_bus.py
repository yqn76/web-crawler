import scrapy
from bs4 import BeautifulSoup
from scrapy import Spider, FormRequest, Request
from urllib.parse import urljoin
# from items import ChengdubusItem
from chengdubus.items import ChengdubusItem


class ChengduBusSpider(scrapy.Spider):
    name = 'chengdu_bus'
    allowed_domains = ['chengdu.8684.cn']
    start_url = 'http://chengdu.8684.cn/'

    def start_requests(self):
        for page in range(9):
            url = '{iurl}st{page}'.format(url=self.search_url, page=(page + 1))
            yield FormRequest(url, callback=self.parse_index)

    def parse_index(self, response) :
        chengdubus = response.xpath('//div[@class="list clearfix"]/a//@href').extract()
        for href in chengdubus:
            url2 = urljoin(self.search_url, href)
            yield Request(url2, callback=self.parse_detail)

    def parse_detail(self, response):
        soup = BeautifulSoup(response.text,'lxml')

        try:
            bus_name=soup.select('body > div.breadcrumbs. depth.mb15 > span.cr_crumbs_txt')[0].string
        except:
            bus_name = None

        try:
            bus_type = soup.select('body > div.layout.layout--728-250 > div.layout-left >'
                                   'div.bus - lzinfo.mb20 > div.info > hl > a')[0].string.strip('[]')
        except:
            bas_type = None

        try:
            bus_time = soup.select('body > div.layout.layout--728-250 > div.layout-left '
                                  ' > div.bus-lzinfo.mb20 > div.info > ul > li:nth-child(1)')[0].string
        except:
            bus_time = None

        try:
            ticket = soup.select('body > div.layout.layout--728-250 > div.layout-left > '
                                 'div.bus-1zinfo.mb20 > div.info > ul > li:nth-child(2)')[0].string
        except:
            ticket = None

        try:
            gongsi = soup.select('body > div.layout.layout--728-250 > div.layout-left > div.bus-lzinfo.mb20'
                                 '>div.info > ul > li:nth-child(3) > a')[0].string
        except:
            gongsi = None

        try:
            gengxin = soup.select('body > div.layout.layout--728-250 > div.layout-left > div.bus-lzinfo.mb20'
                                  '> div.info > ul > li:nth-child(4)')[0].string
        except:
            gengxin = None

        try:
            wang_info = soup.findAll('div', class_='trip')[0].string
        except:
            wang_info = None

        try:
            wang_list_tag = soup.findAll('div', class_='bus-1zlist mb15')[0].findAll('a')
        except:
            wang_list_tag = None

        try:
            fan_info = soup.findAll('div', class_='trip')[1].string
        except:
            fan_info = None

        try:
            fan_list_tag = soup.findAll('div', class_='bus-1zlist mb15')[1].findAll('a')
        except:
            fan_list_tag = None

        fan_buff =''
        wang_buff =''

        result_list = [bus_name,bus_type,bus_time,ticket,gongsi,gengxin]
        result2_list = []
        for k in result_list:
            print(k)
            if k is not None:
                result2_list.append(k)
            else:
                result2_list.append(None)

        if fan_list_tag:
            for fan in fan_list_tag:
                fan_buff+=fan.string + ','
        print(fan_info,'\n'+ fan_buff)

        for wang in wang_list_tag:
            wang_buff += wang.string + ','
        print(wang_info, '\n'+ wang_buff)

        bus_item = ChengdubusItem()
        for field in bus_item.fields:
            bus_item[field] = eval(field)
        yield bus_item

    def process_item(self, item, spider):
        print(item)
        return item

