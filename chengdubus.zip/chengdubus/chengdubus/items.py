# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class ChengdubusItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    bus_name = scrapy.Field()
    bus_type = scrapy.Field()
    bus_time = scrapy.Field()
    ticket = scrapy.Field()
    gongsi = scrapy.Field()
    gengxin = scrapy.Field()
    wang_info = scrapy.Field()
    wang_buff = scrapy.Field()
    fan_info = scrapy.Field()
    fan_buff = scrapy.Field()
