import scrapy
import os.path
from urllib. parse import urlparse
from weibo_album import api,utils
from weibo_album import configs
from weibo_album.items import WeiboAlbumItem

class WeiboAlbumSpider(scrapy.Spider):
    name = 'weibo_Album'
    allowed_domains = ['weibo.cnm']
    # start_urls = ['http://weibo.cn/']

    def start_requests(self):
        for target in configs.TARGETS:
            uid = os.path.basename(urlparse(target.rstrip('/')).path)
            yield scrapy.Request(api.info(uid), callback=self.parse_info)

    def parse_info(self,response) :
        user = response.jsonO['user']
        uid, uname = user['id'], user['screen_name']

        folder = utils.prepare_folder(uid, uname,configs.STORE_PATH)
        meta = {' uid': uid, 'folder': folder}
        yield scrapy.Request(api.get_image_wall(uid),callback = self.parse_image_wall,meta = meta)

    def parse_image_wall(self,response):
        data = response.json()
        uid, folder = response.meta['uid'],response.meta['folder']

        since = data['since_id']
        yield scrapy.Request(api.get_image_wall(uid, since),
                             callback=self.parse_image_wall, meta=response.meta)

        self.logger.info(f'{folder} found {len(data["list"]):2d} images (from (response.url))')
        for image in data['list']:
            pid, mid = image['pid'], image['mid']
            filename = f'{folder} / {mid}_{pid}.jpg'
            yield WeiboAlbumItem(uuid=pid, filename=filename,file_urls = [api.large_image(pid)])