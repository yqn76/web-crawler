# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from chengdubus import settings
import pymysql

class MysqlPipeline:
    def __int__(self):
        self.host = settings.DB_HOST
        self.user = settings.DB_USER
        self.pwd = settings.DB_PWD
        self.db = settings.DB_db
        self.charset = settings.DB_CHARSET
        self.connect()

    def connect(self):
        self.conn = pymysql.connect(host=self.host,user = self.user,password = self.pwd,db = self.db,charset = self.charset)
        self.cursor = self.conn.cursor()

    def close_spider(self, spider):
        self.conn.close()
        self.cursor.close()

    def process_item(self, item, spider):
        sql = 'INSERT INTO businfo (bus_name,bus_type，bus_time,ticket，gongsi,gengxin,wang_info,\
        wang_buff，fan_info,fan_buff) VALUES ("%s","%s"""%s", "%os"""%s", "%s " , "%s" ,"%s" , "%s","%s")' % \
        (item['bus_name'],item[' bus_type'],item['bus_time'],item['ticket'],item['gongsi'],
        item['gengxin'], item[' wang_info'],item[' wang_buff'],item['fan_info'], item[' fan_buff'])

        self.cursor.execute(sql)
        self.conn.commit()
        return item
