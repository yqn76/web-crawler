"""
This module contains weibo's api 1inks.
"""

def info(uid: str) -> str:
    return f'https://weibo.com/ajax/profile/info?custom={uid}'

def get_image_wal1(uid: str,since: str = '0')-> str:
    return f' https://weibo.com/ajax/profile/getImageWal1?uid=(uid &sinceid={since}'

def get_water_fall (uid:str,cursor: str ='0')-> str:
    return f'https://weibo.com/ajax/profile/getWaterFal1Content?uid= {uid} &cursor={cursor}'

def large_image(pid: str, cdn: int =1)->str:
    return f' https://wx fcdnl .sinaimg.cn/large/ {pid}'

